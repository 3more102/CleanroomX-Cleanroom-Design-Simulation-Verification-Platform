# CleanroomX solver-result analysis

Computed from recorded solver outputs; convergence and physical validation are not established. Spatial plots show cell-center samples, not interpolated contours.

## run-c9ae74ad4694

Execution metadata: `[{"case_id": "configuration_1", "configuration_hash": "e1901952173aa7b3af720df0d0431b882b0776c3678ce0050895c18d3c5f818e", "error_count": 0, "solver_build": "10-c4cf895ad8fa", "solver_log_status": "completed", "solver_release": "OpenFOAM Foundation v10", "solver_returncode": 0, "sync_status": "results_synced"}, {"case_id": "configuration_2", "configuration_hash": "08efa221adfeeebc3597927ceb0a1ddb40fb053a512458042cc8d564d9a09da9", "error_count": 0, "solver_build": "10-c4cf895ad8fa", "solver_log_status": "completed", "solver_release": "OpenFOAM Foundation v10", "solver_returncode": 0, "sync_status": "results_synced"}, {"case_id": "configuration_3", "configuration_hash": "a0560ed0c79d4557ff9f48c9109acb848d7ca24975889567be8ddaf43f1b84a3", "error_count": 0, "solver_build": "10-c4cf895ad8fa", "solver_log_status": "completed", "solver_release": "OpenFOAM Foundation v10", "solver_returncode": 0, "sync_status": "results_synced"}]`

Original OpenFOAM field bytes rehashed: True.

| Case | Solver time | Field | Units | Minimum | Volume-weighted mean | Maximum |
|---|---|---|---|---:|---:|---:|
| configuration\_1 | 50 | speed | m/s | 0.010567014276519607 | 0.06856529762974993 | 0.18714769067673825 |
| configuration\_1 | 50 | U\_x | m/s | -0.12707999348640442 | -2.102418082788291e-06 | 0.1270730048418045 |
| configuration\_1 | 50 | U\_y | m/s | -0.0899730995297432 | 3.8740912360583486e-06 | 0.09000640362501144 |
| configuration\_1 | 50 | U\_z | m/s | -0.18707400560379028 | -0.024284634990619402 | 0.05496229976415634 |
| configuration\_1 | 50 | p | m^2/s^2 (kinematic pressure) | -0.0009259600192308426 | 0.0015079563046318375 | 0.015390300191938877 |
| configuration\_1 | 100 | speed | m/s | 0.010207680210877302 | 0.06856340294600316 | 0.18714677723070092 |
| configuration\_1 | 100 | U\_x | m/s | -0.12708300352096558 | -1.8844465077772659e-07 | 0.1270810067653656 |
| configuration\_1 | 100 | U\_y | m/s | -0.08998390287160873 | -1.0885039170293656e-07 | 0.08999619632959366 |
| configuration\_1 | 100 | U\_z | m/s | -0.1870730072259903 | -0.024286082816186334 | 0.05495160073041916 |
| configuration\_1 | 100 | p | m^2/s^2 (kinematic pressure) | -0.0009247660054825246 | 0.00150789279461176 | 0.015389899723231792 |
| configuration\_1 | 150 | speed | m/s | 0.010195215025704278 | 0.06856188220722909 | 0.18714684016499836 |
| configuration\_1 | 150 | U\_x | m/s | -0.12708699703216553 | -1.3730195354990537e-07 | 0.12708500027656555 |
| configuration\_1 | 150 | U\_y | m/s | -0.08998849987983704 | -3.755968886783566e-06 | 0.08999200165271759 |
| configuration\_1 | 150 | U\_z | m/s | -0.1870730072259903 | -0.02428575478110512 | 0.054950401186943054 |
| configuration\_1 | 150 | p | m^2/s^2 (kinematic pressure) | -0.0009242980158887804 | 0.0015078539195100247 | 0.015389899723231792 |
| configuration\_2 | 50 | speed | m/s | 0.0038761848418676775 | 0.03969702863752077 | 0.09872907052561683 |
| configuration\_2 | 50 | U\_x | m/s | -0.08600500226020813 | 0.002680309933490814 | 0.08794520050287247 |
| configuration\_2 | 50 | U\_y | m/s | -0.012253999710083008 | 0.002519468249318398 | 0.019366899505257607 |
| configuration\_2 | 50 | U\_z | m/s | -0.09871900081634521 | -0.024401562663175964 | 0.03528530150651932 |
| configuration\_2 | 50 | p | m^2/s^2 (kinematic pressure) | 0.001561939949169755 | 0.003396539669645588 | 0.00591395003721118 |
| configuration\_2 | 100 | speed | m/s | 0.0034206119813362354 | 0.039592069779131454 | 0.09842981304424307 |
| configuration\_2 | 100 | U\_x | m/s | -0.08592739701271057 | 0.0026728270254819915 | 0.08800370246171951 |
| configuration\_2 | 100 | U\_y | m/s | -0.011810099706053734 | 0.0024718290216293485 | 0.019473200663924217 |
| configuration\_2 | 100 | U\_z | m/s | -0.09841769933700562 | -0.024316294004910966 | 0.0346934013068676 |
| configuration\_2 | 100 | p | m^2/s^2 (kinematic pressure) | 0.0015650199493393302 | 0.0033958831813328694 | 0.005869179964065552 |
| configuration\_2 | 150 | speed | m/s | 0.0028340051234098727 | 0.03965853794522748 | 0.09844748892654455 |
| configuration\_2 | 150 | U\_x | m/s | -0.0859823003411293 | 0.0026642077489870846 | 0.0879174992442131 |
| configuration\_2 | 150 | U\_y | m/s | -0.01173890009522438 | 0.002520829412973866 | 0.0193984005600214 |
| configuration\_2 | 150 | U\_z | m/s | -0.09843649715185165 | -0.02435295368885717 | 0.0350101999938488 |
| configuration\_2 | 150 | p | m^2/s^2 (kinematic pressure) | 0.001557679963298142 | 0.003396284595591068 | 0.005908370018005371 |
| configuration\_3 | 50 | speed | m/s | 0.0010446859087206019 | 0.03321858917642567 | 0.09869343539047813 |
| configuration\_3 | 50 | U\_x | m/s | -0.013494499959051609 | -7.148523057251871e-06 | 0.011524699628353119 |
| configuration\_3 | 50 | U\_y | m/s | -0.013516499660909176 | 3.820735429971793e-05 | 0.013053400442004204 |
| configuration\_3 | 50 | U\_z | m/s | -0.09867870062589645 | -0.025751041199792882 | 0.033649299293756485 |
| configuration\_3 | 50 | p | m^2/s^2 (kinematic pressure) | 0.0005733179859817028 | 0.0015350041319228088 | 0.002137369941920042 |
| configuration\_3 | 100 | speed | m/s | 0.0012076251516390474 | 0.03352095886452267 | 0.09836830836472914 |
| configuration\_3 | 100 | U\_x | m/s | -0.017053799703717232 | -7.568963570968715e-05 | 0.01264179963618517 |
| configuration\_3 | 100 | U\_y | m/s | -0.015616299584507942 | -0.00016904828404504555 | 0.011864599771797657 |
| configuration\_3 | 100 | U\_z | m/s | -0.09835000336170197 | -0.026059611777175938 | 0.023188700899481773 |
| configuration\_3 | 100 | p | m^2/s^2 (kinematic pressure) | 0.0004942870000377297 | 0.0014802207551838364 | 0.0021200201008468866 |
| configuration\_3 | 150 | speed | m/s | 0.0013626643356064788 | 0.03336237605078173 | 0.09878454268649207 |
| configuration\_3 | 150 | U\_x | m/s | -0.01908719912171364 | -8.794036966845751e-05 | 0.012812200002372265 |
| configuration\_3 | 150 | U\_y | m/s | -0.015329199843108654 | -4.5815885988057904e-05 | 0.012533700093626976 |
| configuration\_3 | 150 | U\_z | m/s | -0.09876939654350281 | -0.02556238734106147 | 0.02477169968187809 |
| configuration\_3 | 150 | p | m^2/s^2 (kinematic pressure) | 0.0005503650172613561 | 0.0015218736895702832 | 0.0021068400237709284 |

### Availability and warnings

- room\_airflow\_ach: No verified room cell masks and per-room boundary fluxes in this store
- contaminant\_acceptance: Requires declared concentration semantics, units, source model, and limits
- room\_airflow\_ach: No verified room cell masks and per-room boundary fluxes in this store
- contaminant\_acceptance: Requires declared concentration semantics, units, source model, and limits
- room\_airflow\_ach: No verified room cell masks and per-room boundary fluxes in this store
- contaminant\_acceptance: Requires declared concentration semantics, units, source model, and limits

Mesh diagnostics: `{"ambiguous_fields": [], "counts": {"boundary_patches": 3, "cell_types": {"hexahedra": 720, "polyhedra": 0, "prisms": 0, "pyramids": 0, "tet_wedges": 0, "tetrahedra": 0, "wedges": 0}, "cell_zones": 0, "cells": 720, "face_zones": 0, "faces": 2412, "faces_per_cell": 6, "internal_faces": 1908, "point_zones": 0, "points": 1001, "regions": 1}, "geometry": {"boundary_openness_vector": [0.0, 0.0, 0.0], "cell_volume_range_m3": [0.125, 0.125, 90.0], "coupled_point_location_average": 0.0, "domain_bounding_box": [[0.0, 0.0, 0.0], [6.0, 5.0, 3.0]], "face_area_range_m2": [0.25, 0.25], "geometric_directions": [1, 1, 1], "max_aspect_ratio": 1.0, "max_cell_openness": 0.0, "max_skewness": 0.0, "non_orthogonality_deg_max_average": [0.0, 0.0], "solution_directions": [1, 1, 1]}, "interpretation": "diagnostic_only", "invalid_fields": [], "mesh_result": "mesh_ok", "missing_fields": [], "parse_status": "complete", "patch_topology": [{"description": "non-closed singly connected", "faces": 16, "name": "inlet", "points": 25, "status": "ok"}, {"description": "non-closed singly connected", "faces": 40, "name": "outlet", "points": 66, "status": "ok"}, {"description": "non-closed singly connected", "faces": 448, "name": "walls", "points": 479, "status": "ok"}], "project_acceptance": "not_assessed_no_project_criteria", "reported_check_failures": [], "reported_checks": {"aspect_ratio": "ok", "boundary_definition": "ok", "boundary_openness": "ok", "cell_openness": "ok", "cell_to_face_addressing": "ok", "cell_volumes": "ok", "coupled_point_location": "ok", "face_area_magnitudes": "ok", "face_pyramids": "ok", "face_vertices": "ok", "non_orthogonality": "ok", "number_of_regions": "ok", "patch_topology": "ok", "point_usage": "ok", "skewness": "ok", "upper_triangular_ordering": "ok"}, "schema_version": "cleanroomx.openfoam-checkmesh-diagnostics.v1", "source_log_sha256": "7c173d0c1cea9678eefe85ab56142ca7ed251bfc869739c26395b2a6e70e6e35"}`


Mesh diagnostics: `{"ambiguous_fields": [], "counts": {"boundary_patches": 3, "cell_types": {"hexahedra": 720, "polyhedra": 0, "prisms": 0, "pyramids": 0, "tet_wedges": 0, "tetrahedra": 0, "wedges": 0}, "cell_zones": 0, "cells": 720, "face_zones": 0, "faces": 2412, "faces_per_cell": 6, "internal_faces": 1908, "point_zones": 0, "points": 1001, "regions": 1}, "geometry": {"boundary_openness_vector": [0.0, 0.0, 0.0], "cell_volume_range_m3": [0.125, 0.125, 90.0], "coupled_point_location_average": 0.0, "domain_bounding_box": [[0.0, 0.0, 0.0], [6.0, 5.0, 3.0]], "face_area_range_m2": [0.25, 0.25], "geometric_directions": [1, 1, 1], "max_aspect_ratio": 1.0, "max_cell_openness": 0.0, "max_skewness": 0.0, "non_orthogonality_deg_max_average": [0.0, 0.0], "solution_directions": [1, 1, 1]}, "interpretation": "diagnostic_only", "invalid_fields": [], "mesh_result": "mesh_ok", "missing_fields": [], "parse_status": "complete", "patch_topology": [{"description": "non-closed singly connected", "faces": 30, "name": "inlet", "points": 120, "status": "ok"}, {"description": "non-closed singly connected", "faces": 40, "name": "outlet", "points": 66, "status": "ok"}, {"description": "non-closed singly connected", "faces": 434, "name": "walls", "points": 488, "status": "ok"}], "project_acceptance": "not_assessed_no_project_criteria", "reported_check_failures": [], "reported_checks": {"aspect_ratio": "ok", "boundary_definition": "ok", "boundary_openness": "ok", "cell_openness": "ok", "cell_to_face_addressing": "ok", "cell_volumes": "ok", "coupled_point_location": "ok", "face_area_magnitudes": "ok", "face_pyramids": "ok", "face_vertices": "ok", "non_orthogonality": "ok", "number_of_regions": "ok", "patch_topology": "ok", "point_usage": "ok", "skewness": "ok", "upper_triangular_ordering": "ok"}, "schema_version": "cleanroomx.openfoam-checkmesh-diagnostics.v1", "source_log_sha256": "73d03d049ceeaa8b94113ef141004c7d83b4be7fca20f9885f0d1f0e758af65e"}`


Mesh diagnostics: `{"ambiguous_fields": [], "counts": {"boundary_patches": 3, "cell_types": {"hexahedra": 720, "polyhedra": 0, "prisms": 0, "pyramids": 0, "tet_wedges": 0, "tetrahedra": 0, "wedges": 0}, "cell_zones": 0, "cells": 720, "face_zones": 0, "faces": 2412, "faces_per_cell": 6, "internal_faces": 1908, "point_zones": 0, "points": 1001, "regions": 1}, "geometry": {"boundary_openness_vector": [0.0, 0.0, 0.0], "cell_volume_range_m3": [0.125, 0.125, 90.0], "coupled_point_location_average": 0.0, "domain_bounding_box": [[0.0, 0.0, 0.0], [6.0, 5.0, 3.0]], "face_area_range_m2": [0.25, 0.25], "geometric_directions": [1, 1, 1], "max_aspect_ratio": 1.0, "max_cell_openness": 0.0, "max_skewness": 0.0, "non_orthogonality_deg_max_average": [0.0, 0.0], "solution_directions": [1, 1, 1]}, "interpretation": "diagnostic_only", "invalid_fields": [], "mesh_result": "mesh_ok", "missing_fields": [], "parse_status": "complete", "patch_topology": [{"description": "non-closed singly connected", "faces": 30, "name": "inlet", "points": 120, "status": "ok"}, {"description": "non-closed singly connected", "faces": 30, "name": "outlet", "points": 120, "status": "ok"}, {"description": "non-closed singly connected", "faces": 444, "name": "walls", "points": 506, "status": "ok"}], "project_acceptance": "not_assessed_no_project_criteria", "reported_check_failures": [], "reported_checks": {"aspect_ratio": "ok", "boundary_definition": "ok", "boundary_openness": "ok", "cell_openness": "ok", "cell_to_face_addressing": "ok", "cell_volumes": "ok", "coupled_point_location": "ok", "face_area_magnitudes": "ok", "face_pyramids": "ok", "face_vertices": "ok", "non_orthogonality": "ok", "number_of_regions": "ok", "patch_topology": "ok", "point_usage": "ok", "skewness": "ok", "upper_triangular_ordering": "ok"}, "schema_version": "cleanroomx.openfoam-checkmesh-diagnostics.v1", "source_log_sha256": "be14d343d1b9de8cde877166fb06404aa4aabf11ccfe043a28c4a12f5562b0ca"}`


Full source paths, SHA-256 values, native field metadata, calculation methods, and execution status are in analysis.json.

## Figures and data

graphs.csv contains every plotted point. graphs.json records filters, source hashes, methods, and unavailable states. selections.csv contains all selected-cell statistics and mesh-volume coverage, including empty selections. residuals.csv contains all parsed linear solves. cell-data-NN.csv contains all selected cells before display sampling, when a spatial graph is exported.

### Figure 1: speed: volume-weighted history

All volume cells; volume-weighted mean, minimum and maximum; exact solver-time selection

![Figure 1](figure-01.png)

| Case / time | Selected cells | Selected volume (m³) | Mesh volume coverage | Mean | Range |
| --- | ---: | ---: | ---: | ---: | --- |
| run-c9ae74ad4694 / configuration\_1 / 50 | 720 / 720 | 90 | 100% | 0.0685653 m/s | 0.010567 to 0.187148 |
| run-c9ae74ad4694 / configuration\_1 / 100 | 720 / 720 | 90 | 100% | 0.0685634 m/s | 0.0102077 to 0.187147 |
| run-c9ae74ad4694 / configuration\_1 / 150 | 720 / 720 | 90 | 100% | 0.0685619 m/s | 0.0101952 to 0.187147 |
| run-c9ae74ad4694 / configuration\_2 / 50 | 720 / 720 | 90 | 100% | 0.039697 m/s | 0.00387618 to 0.0987291 |
| run-c9ae74ad4694 / configuration\_2 / 100 | 720 / 720 | 90 | 100% | 0.0395921 m/s | 0.00342061 to 0.0984298 |
| run-c9ae74ad4694 / configuration\_2 / 150 | 720 / 720 | 90 | 100% | 0.0396585 m/s | 0.00283401 to 0.0984475 |
| run-c9ae74ad4694 / configuration\_3 / 50 | 720 / 720 | 90 | 100% | 0.0332186 m/s | 0.00104469 to 0.0986934 |
| run-c9ae74ad4694 / configuration\_3 / 100 | 720 / 720 | 90 | 100% | 0.033521 m/s | 0.00120763 to 0.0983683 |
| run-c9ae74ad4694 / configuration\_3 / 150 | 720 / 720 | 90 | 100% | 0.0333624 m/s | 0.00136266 to 0.0987845 |

### Figure 2: Linear solver residual history

Each logged solve; repeated correctors retained. Zero values preserved; symlog axis.; display reduction preserves endpoints and bucket extrema; full histories in analysis.json/residuals.csv

![Figure 2](figure-02.png)

### Figure 3: Boundary airflow balance \| solver time 150

Signed solver phi sums; negative inlet is inflow; no project acceptance threshold

![Figure 3](figure-03.png)

### Figure 4: Whole-domain inlet supply ACH \| solver time 150

3600 \* gross inlet solver phi / sum of verified VTK cell volumes; whole-domain supply ACH

![Figure 4](figure-04.png)
